let anotherMessage = "Hello World!";
console.log(anotherMessage);

/* let message = "123"; error */