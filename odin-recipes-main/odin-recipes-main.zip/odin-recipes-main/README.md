# odin-recipes

This is a simple HTML-only website project for cooking recipes from the game "Don't Starve".
