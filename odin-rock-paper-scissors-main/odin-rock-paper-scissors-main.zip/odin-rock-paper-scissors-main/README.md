# odin-rock-paper-scissors

This is a rock-paper-scissors game with a different flavour.

This is a high school showdown!!!

The rock will be Jock
the paper will be Teacher
the scissors will be Nerd

So Jock beats Nerd, Teacher beats Jock and Nerd beats Teacher.

At the start of the round you will be asked to choose your class.
There will also be speacial character that you unlock with a cheatcode, that will beat everyone.
