# odin-web-page
final task of the css section :)

Used Images -->
Logo: https://pixabay.com/users/piyapong89-7158719/
Header-img: https://pixabay.com/users/6617564-6617564/
content-top-first-image: https://pixabay.com/users/anrita1705-11109462/
content-top-second-image: https://pixabay.com/users/dreamypixel-6094827/
content-top-third-image: https://pixabay.com/users/anrita1705-11109462/
content-top-fourth-image: https://pixabay.com/users/andhoj-7200068/